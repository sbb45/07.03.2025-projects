<?php
if (isset($_POST['submit'])) {
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ . "/files/";

        // Создаем папку, если ее нет
        if (!is_dir($upload_dir) && !mkdir($upload_dir, 0777, true)) {
            die("Не удалось создать папку!");
        }

        $file = $_FILES['image']['name'];
        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));

        // Проверяем расширение
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'pdf']; // пример разрешенных типов
        if (!in_array($extension, $allowed)) {
            die("Только файлы JPG, PNG, GIF и PDF разрешены!");
        }

        $new_name = uniqid('', true) . "." . $extension;
        $upload_path = $upload_dir . $new_name;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
            echo "Файл загружен: " . htmlspecialchars($new_name);
        } else {
            echo "Ошибка перемещения файла!";
        }
    } else {
        echo "Ошибка загрузки: " . $_FILES['image']['error'];
    }
}
?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Загрузка файлов</title>
</head>
<body>
<form action="" method="POST" enctype="multipart/form-data">
    <h1>Загрузите ваш файл</h1>
    <input type="file" name="image">
    <button type="submit" name="submit">Загрузить файл</button>
</form>
</body>
</html>
