<?php
$w = 400;
$h = 120;
$font = __DIR__ . '/arial.ttf';

$canvas = imagecreatetruecolor($w, $h);
$colorBg = imagecolorallocate($canvas, 0, 0, 200);
$charts = 'QWERTYUIOPASDFGHJKLZXCVBNM1234567890';
$colorText = imagecolorallocate($canvas, 200, 200, 200);
$colorShadow = imagecolorallocate($canvas, 0, 0, 0);
imagefill($canvas, 0, 0, $colorBg);
for($i = 0; $i<4; $i++){
    $text = $charts[rand(0, strlen($charts) - 1)];
    imagefilledellipse($canvas, rand(0, $w), rand(0, $h), 14, 14, $colorShadow);
    imagettftext($canvas, 50, rand(10,30), rand(0, $w-30), rand(50, $h-30), $colorText, $font, $text);
    imageline($canvas, 0, rand(0, $h), $w, rand(0, $h), $colorText);
}

header('Content-Type: image/png');
imagepng($canvas);
?>