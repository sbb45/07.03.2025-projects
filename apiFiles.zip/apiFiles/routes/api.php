<?php

use App\Http\Controllers\AccessFilesController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\FilesController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::post('/registration', [AuthController::class, 'registration']);
Route::post('/authorization', [AuthController::class, 'authorization']);
Route::middleware('auth:sanctum')->group(function(){
    Route::get('/logout', [AuthController::class, 'logout']);

    Route::post('/files', [FilesController::class, 'uploadFiles']);
    Route::get('/files/disk', [AccessFilesController::class, 'getFiles']);
    Route::get('/shared', [AccessFilesController::class, 'sharedFiles']);

    Route::get('/files/{file:file_id}', [FilesController::class, 'downloadFile']);
    Route::middleware('isOwner')->group(function(){
        Route::patch('/files/{file:file_id}', [FilesController::class, 'patchFile']);
        Route::delete('/files/{file:file_id}', [FilesController::class, 'deleteFile']);

        Route::post('/files/{file:file_id}/accesses', [AccessFilesController::class, 'addAccess']);
        Route::delete('/files/{file:file_id}/accesses', [AccessFilesController::class, 'deleteAccess']);
    });

});
