<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddAccessRequest;
use App\Http\Resources\AccessResource;
use App\Http\Resources\FilesResource;
use App\Http\Resources\SharedResource;
use App\Models\AccessFile;
use App\Models\File;
use App\Models\User;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

class AccessFilesController extends Controller
{
    /**
     * Добавление доступа
     * @param AddAccessRequest $request
     * @param File $file
     * @return Application|\Illuminate\Foundation\Application|Response|ResponseFactory
     */
    public function addAccess(AddAccessRequest $request, File $file){
        $accessUser = User::where('email', $request->email)->firstOrFail();
        auth()->user()->accessFiles()->create(['file_id' => $file->id, 'access_user' => $accessUser->id, 'type'=>'co-author']);
        $accessesUser = AccessFile::with('accessUser')->where('file_id', $file->id)->get();
        return response(AccessResource::collection($accessesUser));
    }

    /**
     * Удаление доступа
     * @param AddAccessRequest $request
     * @param File $file
     * @return Application|ResponseFactory|\Illuminate\Foundation\Application|\Illuminate\Http\Resources\Json\AnonymousResourceCollection|Response
     */
    public function deleteAccess(AddAccessRequest $request, File $file){
        $user= User::where('email', $request->email)->firstOrFail();
        if($user->id == auth()->id())
            return response(["message"=>'Forbidden for you'],403);
        AccessFile::where('file_id', $file->id)->where('access_user', $user->id)->delete();
        $accessesUser = AccessFile::with('user')->where('file_id', $file->id)->get();
        return response(AccessResource::collection($accessesUser));
    }

    /**
     * Получение файлов пользователя
     * @return Application|ResponseFactory|\Illuminate\Foundation\Application|Response
     */
    public function getFiles(){
        $files = auth()->user()->files()->with('accessFiles', 'user')->get();

        $filesResponse = $files->map(function ($file) {
            return [
                'file_id' => $file->file_id,
                'name' => $file->name,
                'url' => url('storage/files/' . $file->file_id),
                'accesses' => $file->accessFiles->map(function ($access) {
                    return [
                        'fullname' => $access->accessUser->first_name . ' ' . $access->accessUser->last_name,
                        'email' => $access->accessUser->email,
                        'type' => $access->type,
                    ];
                }),
            ];
        });
        return response($filesResponse);
    }

    /**
     * Доступные файлы
     * @return Application|\Illuminate\Foundation\Application|Response|ResponseFactory
     */
    public function sharedFiles(){
        $files = AccessFile::where('access_user', auth()->id())->where('type', 'co-author')->with('file')->get();
        return response(SharedResource::collection($files));

    }

}
