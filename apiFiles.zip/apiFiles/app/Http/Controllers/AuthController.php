<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterRequest;
use App\Models\User;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Http\Response;

class AuthController extends Controller
{
    /**
     * Регистриация
     * @param RegisterRequest $request
     * @return Application|ResponseFactory|\Illuminate\Foundation\Application|Response
     */
    public function registration(RegisterRequest $request){
        $user = User::create($request->validated());
        $token = $user->createToken($user->id . date('YmdHis'))->plainTextToken;
        return response(["success"=>true, "message"=>'Success', 'token'=>$token]);
    }

    /**
     * Авторизация
     * @param LoginRequest $request
     * @return Application|ResponseFactory|\Illuminate\Foundation\Application|Response
     */
    public function authorization(LoginRequest $request){
        if(!auth()->attempt($request->validated())){
            return response(['success'=>false,"message"=>"Login failed"], 401);
        }
        $user = auth()->user();
        $token = $user->createToken($user->id . date('YmdHis'))->plainTextToken;
        return response(["success"=>true, "message"=>'Success', 'token'=>$token]);
    }

    /**
     * Выход из аккаунта
     * @return Application|ResponseFactory|\Illuminate\Foundation\Application|Response
     */
    public function logout(){
        $user = auth()->user();
        $user->currentAccessToken()->delete();
        return response(['success'=>true,"message"=>"Logout"]);
    }
}
