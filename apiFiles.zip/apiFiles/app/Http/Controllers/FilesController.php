<?php

namespace App\Http\Controllers;

use App\Http\Requests\FileRenameRequest;
use App\Http\Requests\FilesRequest;
use App\Models\File;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\BinaryFileResponse;


class FilesController extends Controller{
    /**
     * Загрузка файла
     * @param FilesRequest $request
     * @return Application|ResponseFactory|\Illuminate\Foundation\Application|Response
     */
    public function uploadFiles(FilesRequest $request){
        $response = [];
        if($request->hasFile('files')){
            foreach($request->file('files')as $file){
                try {
                    $fileName = $file->getClientOriginalName();
                    $file_id = substr(Str::uuid(), 0 ,10);
                    $path =  $file->storeAs('files', $file_id.".".pathinfo($fileName, PATHINFO_EXTENSION), 'public');

                    $extension = $file->getClientOriginalExtension();
                    $baseName = pathinfo($fileName, PATHINFO_FILENAME);
                    $counter = 1;

                    while (auth()->user()->files()->where('name', $fileName)->exists()) {
                        $fileName = $baseName . "($counter)." . $extension;
                        $counter++;
                    }

                    $recordFile = auth()->user()->files()->create([
                        "name"=> $fileName,
                        "file_id"=> $file_id,
                        "url" =>url('/').storage::url($path),
                    ]);
                    auth()->user()->accessFiles()->create(["access_user"=>auth()->id(), "file_id"=>$recordFile->id]);
                    $response[]=[
                        "success"=>true,
                        "message"=>'Success',
                        "name"=>$fileName,
                        "url"=>url('/').storage::url($path),
                        "file_id"=>$file_id,
                    ];
                }catch(\Exception $e){
                    $response[]=[
                        "success"=>false,
                        "message"=>'File not loaded',
                        'name'=> $file->getClientOriginalName()
                    ];
                }

            }
        }
        return response([$response]);
    }

    /**
     * Смена имени файла
     * @param FileRenameRequest $request
     * @param File $file
     * @return Application|ResponseFactory|\Illuminate\Foundation\Application|Response
     */
    public function patchFile(FileRenameRequest $request, File $file){
        $newFileName = $request->name;
        $fileExtension = pathinfo($file->name, PATHINFO_EXTENSION);
        if($file->user_id !== auth()->id()){
            return response(["message"=>'Forbidden for you'],403);
        }
        if(auth()->user()->files()->where('name', $newFileName)->exists()){
            return response(["message"=>'Файл с таким названием уже существует'],403);
        }
        $file->update(["name"=>$newFileName.".".$fileExtension]);
        return response(["success"=>true,'message'=>'Renamed']);
    }

    /**
     * Удаление файла
     * @param File $file
     * @return Application|ResponseFactory|\Illuminate\Foundation\Application|Response
     */
    public function deleteFile(File $file){
        $file->delete();
        return response(["success"=>true,'message'=>'File already deleted']);
    }

    /**
     * Скачивание файла
     * @param File $file
     * @return BinaryFileResponse
     */
    public function downloadFile(File $file){
        $path = public_path('storage/files/'. basename($file->url));
        return response()->download($path);
    }
}

