<?php

namespace App\Http\Resources;

use App\Models\AccessFile;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AccessResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'fullname'=>$this->accessUser->first_name ." ". $this->accessUser->last_name,
            'email' => $this->accessUser->email,
            'type' => $this->type,
        ];
    }



    /**
     * Отключить обертку "data"
     */
    public static $wrap = null;
}
