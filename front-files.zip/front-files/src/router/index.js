import { createRouter, createWebHistory } from 'vue-router'
import RegistrationView from "@/views/RegistrationView.vue";
import AuthView from "@/views/AuthView.vue";
import FilesViews from "@/views/FilesViews.vue";
import FilesAccessViews from "@/views/FilesAccessViews.vue";
import RenameView from "@/views/RenameView.vue";
import AccessFileView from "@/views/AccessFileView.vue";


const routes = [
  {
    path: '/registration',
    name: 'registration',
    component: RegistrationView
  },
  {
    path: '/authorization',
    name: 'authorization',
    component: AuthView
  },
  {
    path: '/files',
    name: 'files',
    component: FilesViews,
    requiredAuth: true
  },
  {
    path: '/file/rename',
    name: 'renameFile',
    component: RenameView,
    requiredAuth: true
  },
  {
    path: '/shared',
    name: 'shared',
    component: FilesAccessViews,
    requiredAuth: true
  },
  {
    path: '/file/access',
    name: 'accessFile',
    component: AccessFileView,
    requiredAuth: true
  },
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

router.beforeEach((to,from,next)=>{
  const isAuth = localStorage.getItem('token')
  if(!isAuth && to.matched.some(record=>record.meta.requiredAuth)){
    next({name:'authorization'})
  }else next();
})

export default router
