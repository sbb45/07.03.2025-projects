<script setup>
import {ref} from "vue";
import {response} from "@/components/response";
import {setAuth} from "@/components/isAuth";
import router from "@/router";

const body = ref({})
const errors = ref({})

async function auth(){
  errors.value ={};
  const bodyJson = JSON.stringify(body.value)
  const res = await response('authorization', {method:'POST', body: bodyJson})
  console.log(res)
  if(res.status === 422)
    errors.value = Object.fromEntries( Object.entries(res.json.message).map(([key,value])=>[key,value[0]]) )
  if(res.status === 200)
    setAuth(res.json.token); router.push('/files');
  if(res.status === 401){
    errors.value = res.json
  }
}
</script>

<template>
  <div class="card shadow-lg px-4 py-5 col-4 mx-auto" style="border-radius: 16px">
    <h1 class="mb-3">Авторизация</h1>
      <div class="col mb-3">
        <input type="email" class="form-control" v-model="body.email" :class="{'is-invalid': errors.email}" placeholder="Эл. почта">
        <p class="text-center text-danger mb-0">{{errors.email}}</p>
      </div>
      <div class="col mb-3">
        <input type="password" class="form-control" v-model="body.password" :class="{'is-invalid': errors.password}" placeholder="Пароль">
        <p class="text-center text-danger mb-0">{{errors.password}}</p>
      </div>
    <button class="btn btn-success" @click="auth">Войти</button>
  </div>

  <div v-if="errors.message" class="toast show align-items-center text-bg-danger position-absolute end-0 border-0" style="top: 8%" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body">
        {{errors.message}}
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</template>

<style scoped>

</style>