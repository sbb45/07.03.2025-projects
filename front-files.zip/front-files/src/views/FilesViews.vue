<script setup>
import {onMounted, ref} from "vue";
  import {response} from "@/components/response";

  const files = ref({})
  const isDownload = ref(null);
  const isDelete = ref(null);
  const deleteCont = ref(null)

  async function getFiles(){
    files.value = await response('files/disk')
  }

  async function deleteContext(id){
    deleteCont.value = id
  }

  async function deleteFile(){
    const res = await response(`files/${deleteCont.value}`, {method:'DELETE'})
    console.log(res)
    isDelete.value = true
    getFiles()
  }
  async function download(file){
    await response(`files/${file}`, {}, true)
    isDownload.value = true
  }
  onMounted(()=>{
    getFiles()
  })
</script>

<template>
  <h1 class="mb-4">Ваши файлы</h1>
  <div class="row col-8 mx-auto gap-4 justify-content-center">
    <div class="card" style="width: 14rem;" v-for="(file,index) in files.json" :key="index">
      <div class="card-body">
        <i class="bi bi-file-earmark" style="font-size: 6rem;"></i>
        <h3 class="card-title">{{ file.name }}</h3>
        <h5 class="card-subtitle mb-2 text-body-secondary">{{file.file_id}}</h5>
        <div class="position-absolute top-0 end-0">
          <div class="dropdown">
            <button class="btn " type="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="bi bi-three-dots"></i>
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#" @click="deleteContext(file.file_id)" data-bs-toggle="modal" data-bs-target="#deleteFileModal">Удалить</a></li>
              <li><router-link :to="{name:'renameFile', query: {id: file.file_id}}"  class="dropdown-item" href="#">Редактировать</router-link></li>
              <li><a class="dropdown-item" @click="download(file.file_id)" href="#">Скачать</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><router-link :to="{name: 'accessFile', query: {id:file.file_id}}" class="dropdown-item" href="#">Права доступа</router-link></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="modal  fade " id="deleteFileModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Удаление файла</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Вы уверены что хотите удалить файл?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
          <button type="button" class="btn btn-danger" data-bs-dismiss="modal" @click="deleteFile">Удалить файл</button>
        </div>
      </div>
    </div>
  </div>

  <div v-if="isDelete" class="toast show align-items-center text-bg-danger position-absolute end-0 border-0" style="top: 8%" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body">
        Файл удален
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
  <div v-if="isDownload" class="toast show align-items-center text-bg-success position-absolute end-0 border-0" style="top: 8%" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body">
        Файл успешно скачан
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</template>

<style scoped>

</style>