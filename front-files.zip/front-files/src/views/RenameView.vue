<script setup>
import {ref} from "vue";
import {response} from "@/components/response";
import { useRoute } from 'vue-router';

const route = useRoute();
const fileId = route.query.id;

const body = ref({})
const errors = ref({})

async function rename(){
  const bodyJson = JSON.stringify(body.value)
  const res = await response(`files/${fileId}`, {method:'PATCH', body:bodyJson})
  if(res.status === 422)
    errors.value = Object.fromEntries( Object.entries(res.json.message).map(([key,value])=>[key,value[0]]) )
  if(res.status ===200)
    errors.value = res.json

}
</script>

<template>
  <div class="card shadow-lg px-4 py-5 col-3 mx-auto" style="border-radius: 16px">
    <h1 class="mb-3">Изменить имя файла</h1>
      <div class="col mb-3">
        <input type="email" class="form-control" v-model="body.name" :class="{'is-invalid': errors.name}" placeholder="Имя файла">
        <p class="text-center text-danger mb-0">{{errors.name}}</p>
      </div>
      <button class="btn btn-success" @click="rename">Сохранить</button>
  </div>
  <router-link to="/files" type="button" class="btn btn-secondary mt-4 px-4 py-2" >Назад</router-link>

  <div v-if="errors.message" class="toast show align-items-center text-bg-success position-absolute end-0 border-0" style="top: 8%" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body">
        {{errors.message}}
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>

</template>

<style scoped>

</style>