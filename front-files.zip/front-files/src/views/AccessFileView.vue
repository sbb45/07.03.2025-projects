<script setup>
import {useRoute} from "vue-router";

const route = useRoute()
const fileid = route.query.id
</script>

<template>
{{fileid}}
</template>

<style scoped>

</style>