<script setup>
  import {ref} from "vue";
  import {response} from "@/components/response";
  import {setAuth} from "@/components/isAuth";
  import router from "@/router";
  import Input from "@/components/Input.vue";

  const body = ref({})
  const errors = ref({})

  async function register(){
    errors.value ={};
    const bodyJson = JSON.stringify(body.value)
    const res = await response('registration', {method:'POST', body: bodyJson})
    if(res.status === 422)
      errors.value = res.json.message//Object.fromEntries( Object.entries(res.json.message).map(([key,value])=>[key,value[0]]) )
    if(res.status === 200)
      router.push('/authorization')
  }
</script>

<template>
  <div class="card shadow-lg px-4 py-5 col-5 mx-auto" style="border-radius: 16px">
    <h1 class="mb-3">Регистрация</h1>
    <div class="row mb-3">
      <Input v-model="body.first_name" name="first_name" :errors="errors" placeholder="Имя"/>
      <div class="col">
        <input type="text" class="form-control" v-model="body.last_name" :class="{'is-invalid': errors.last_name}" placeholder="Фамилия">
        <p class="text-center text-danger mb-0">{{errors.last_name}}</p>
      </div>
    </div>
    <div class="row mb-3">
      <div class="col">
        <input type="email" class="form-control" v-model="body.email" :class="{'is-invalid': errors.email}" placeholder="Эл. почта">
        <p class="text-center text-danger mb-0">{{errors.email}}</p>
      </div>
      <div class="col">
        <input type="password" class="form-control" v-model="body.password" :class="{'is-invalid': errors.password}" placeholder="Пароль">
        <p class="text-center text-danger mb-0">{{errors.password}}</p>
      </div>
    </div>
    <button class="btn btn-success" @click="register">Зарегистрироваться</button>
  </div>
</template>

<style scoped>

</style>