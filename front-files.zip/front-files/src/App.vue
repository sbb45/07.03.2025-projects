<script setup>
import {authStatus, logout} from "@/components/isAuth";
import {response} from "@/components/response";
import router from "@/router";
async function authLogout(){
  await response('logout')
  logout()
  router.push({name: 'authorization'})
}
</script>
<template>
  <nav class="navbar navbar-expand-lg bg-body-tertiary px-4 mb-5">
    <div class="container-fluid">
      <a class="navbar-brand fs-4" href="#">CloudFiles</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <router-link v-if="authStatus.isAuth" class="nav-link fs-5" to="/files">Файлы</router-link>
          </li>
          <li class="nav-item">
            <router-link v-if="authStatus.isAuth" class="nav-link fs-5" to="/shared">Доступные файлы</router-link>
          </li>
        </ul>
        <ul class="navbar-nav mb-2 mb-lg-0">
          <li class="nav-item">
            <router-link v-if="authStatus.isAuth" @click="authLogout" class="nav-link fs-5" to="/authorization">Выйти</router-link>
          </li>
          <li class="nav-item">
            <router-link v-if="!authStatus.isAuth" class="nav-link fs-5" to="/authorization">Авторизация</router-link>
          </li>
          <li class="nav-item">
            <router-link v-if="!authStatus.isAuth" class="nav-link fs-5" to="/registration">Регистрация</router-link>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <router-view/>
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #42b983;
}
</style>