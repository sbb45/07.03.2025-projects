export async function response(host, data, isDownload = false){
    data={
        bearer: localStorage.getItem('token'),
        method: 'GET',
        body: null,
        headers: {},
        ...data
    }
    const headers ={
        'Authorization': `Bearer ${data.bearer}`,
        ...data.headers
    }
    if(!(data.body instanceof FormData)){
        headers['Content-Type'] = 'application/json'
    }
    const res = await fetch(`http://127.0.0.1:8000/api/${host}`,{
        method: data.method,
        body: data.body,
        headers
    })
    if(isDownload){
        const fileUrl = URL.createObjectURL(await  res.blob())
        const a = Object.assign(document.createElement('a'),{
            href: fileUrl,
            download: "file_" + Date.now()
        })
        a.click()
        URL.revokeObjectURL(fileUrl)
        return
    }
    const resJson = await res.json()
    return {status: res.status, json: resJson}
}