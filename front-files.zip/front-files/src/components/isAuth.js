import {reactive} from "vue";

export const authStatus = reactive({
    isAuth: !!localStorage.getItem('token')
})
export function setAuth(token){
    localStorage.setItem('token', token)
    authStatus.isAuth = !!token
}
export function logout(){
    localStorage.removeItem('token')
    authStatus.isAuth = false
}