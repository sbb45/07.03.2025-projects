<script setup>
const props = defineProps({
  errors: Object,
  name: String,
  placeholder: String
})
const model = defineModel()
</script>

<template>
  <div class="col">
    <input type="text" class="form-control" v-model="model" :class="{'is-invalid': errors[name]}" :placeholder>
    <p class="text-center text-danger mb-0">{{errors[name]?.join(' ')}}</p>
  </div>
</template>

<style scoped>

</style>